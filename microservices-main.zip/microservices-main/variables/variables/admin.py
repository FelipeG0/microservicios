from django.contrib import admin
from . models import Variable

# Register your models here.
admin.site.register(Variable)