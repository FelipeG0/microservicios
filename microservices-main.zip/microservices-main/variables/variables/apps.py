from django.apps import AppConfig


class VariablesConfig(AppConfig):
    name = 'variables'
