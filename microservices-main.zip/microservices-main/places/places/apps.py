from django.apps import AppConfig


class PlacesConfig(AppConfig):
    name = 'places'
